git config --list -global
